import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Fish, Heart, Waves, ImagePlus } from 'lucide-react';

interface BirthdayPageProps {
  onStart: () => void;
}

const BirthdayPage: React.FC<BirthdayPageProps> = ({ onStart }) => {
  const [imgSrc, setImgSrc] = useState('anna.jpg');
  const [imgError, setImgError] = useState(false);

  const handleImgError = () => {
    // Try common variations if the first one fails
    if (imgSrc === 'anna.jpg') setImgSrc('Anna.jpg');
    else if (imgSrc === 'Anna.jpg') setImgSrc('anna.jpeg');
    else if (imgSrc === 'anna.jpeg') setImgSrc('Anna.jpeg');
    else if (imgSrc === 'Anna.jpeg') setImgSrc('anna.png'); // Just in case
    else setImgError(true);
  };

  return (
    <div className="h-screen w-full bg-gradient-to-b from-blue-100 to-blue-300 relative overflow-hidden">
      
      {/* Background Decor */}
      <motion.div 
        className="absolute top-10 left-10 text-blue-400 opacity-20 pointer-events-none"
        animate={{ y: [0, 20, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
      >
        <Fish size={120} />
      </motion.div>
      <motion.div 
        className="absolute bottom-20 right-10 text-blue-500 opacity-20 pointer-events-none"
        animate={{ y: [0, -30, 0] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      >
        <Fish size={160} style={{ transform: 'scaleX(-1)' }} />
      </motion.div>
      <motion.div 
        className="absolute top-1/3 right-1/4 text-cyan-500 opacity-15 pointer-events-none"
        animate={{ x: [0, 50, 0] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      >
        <Fish size={80} />
      </motion.div>
      <motion.div 
        className="absolute bottom-1/4 left-1/4 text-indigo-400 opacity-15 pointer-events-none"
        animate={{ x: [0, -40, 0], rotate: [0, 10, 0] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      >
        <Fish size={100} style={{ transform: 'scaleX(-1)' }} />
      </motion.div>

      {/* Scrollable Content Overlay */}
      <div className="absolute inset-0 overflow-y-auto overflow-x-hidden z-10 flex flex-col">
        <div className="flex-grow flex flex-col items-center justify-center p-4 min-h-full py-10">
          {/* Content Container - No global background, just layout */}
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, type: "spring" }}
            className="max-w-4xl w-full flex flex-col items-center"
          >
            {/* Photo Frame - Standalone */}
            <motion.div 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="relative mb-6 md:mb-8 group"
            >
              <div className="absolute inset-0 bg-blue-400 rounded-full blur-xl opacity-40 group-hover:opacity-60 transition-opacity"></div>
              
              {!imgError ? (
                <motion.img 
                  src={imgSrc}
                  alt="Anna" 
                  onError={handleImgError}
                  className="relative w-48 h-48 md:w-60 md:h-60 rounded-full object-cover border-4 border-white shadow-2xl bg-blue-100 z-10"
                  whileHover={{ scale: 1.05, rotate: 3 }}
                  transition={{ type: "spring", stiffness: 300 }}
                />
              ) : (
                <div className="relative w-48 h-48 md:w-60 md:h-60 rounded-full border-4 border-white shadow-2xl bg-gray-200 flex flex-col items-center justify-center text-gray-500 z-10 p-4">
                  <ImagePlus size={32} />
                  <span className="text-xs mt-2 font-bold text-center">
                    Photo not found<br/>
                    Is it named <em>anna.jpg</em>?
                  </span>
                </div>
              )}

              <motion.div 
                className="absolute -bottom-2 -right-2 bg-pink-500 text-white p-3 rounded-full shadow-lg z-20 border-2 border-white"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
              >
                <Heart size={28} fill="currentColor" />
              </motion.div>
            </motion.div>

            {/* Title Block - Glass effect just on text */}
            <div className="bg-white/30 backdrop-blur-md px-8 py-4 rounded-2xl shadow-sm mb-6 border border-white/40">
                <h1 className="font-bubble text-2xl sm:text-3xl md:text-5xl text-blue-800 drop-shadow-sm text-center">
                Happy birthday, you extremely gorgeous woman
                </h1>
            </div>

            {/* Message Block - Glass effect just on text */}
            <div className="bg-white/40 backdrop-blur-md p-6 md:p-8 rounded-2xl shadow-sm mb-10 border border-white/50 max-w-2xl">
                <p className="text-gray-900 text-lg md:text-2xl font-medium leading-relaxed font-sans text-center">
                Anna, of all the things that happened in 2025, you were the absolute best part. 
                Your smile is my favorite view, and your humor is my favorite language. 
                I’m so lucky to know you.
                </p>
            </div>

            <motion.button
              onClick={onStart}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold py-4 px-10 rounded-full text-xl shadow-xl flex items-center gap-3 transition-all border-2 border-white/20"
            >
              <Waves size={24} />
              Design Your Aquarium
              <Waves size={24} />
            </motion.button>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default BirthdayPage;
