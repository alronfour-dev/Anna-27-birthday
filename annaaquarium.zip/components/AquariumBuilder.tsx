import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { v4 as uuidv4 } from 'uuid';
import { 
  Sun, Moon, Sunset, Wind, Trash2, RotateCw, ZoomIn, ZoomOut, Info,
  Dices, Anchor, Fish, Leaf, Box, ArrowLeft, Eraser, Palette, X
} from 'lucide-react';
import { AquariumItem, ItemCategory, ItemDefinition } from '../types';
import { ITEM_DEFINITIONS } from '../constants';
import { analyzeAquarium } from '../services/geminiService';

interface AquariumBuilderProps {
  onBack: () => void;
}

const SAND_COLORS = [
  { id: 'none', name: 'No Sand', color: 'transparent' },
  { id: 'gold', name: 'Golden Sand', color: '#e6c288' }, // Classic sand
  { id: 'white', name: 'White Sand', color: '#f5f5f5' }, // Caribbean
  { id: 'black', name: 'Volcanic Sand', color: '#2d2d2d' }, // Volcanic
  { id: 'pink', name: 'Pink Sand', color: '#f3d1d6' }, // Bermuda
];

const BACKGROUNDS = [
  { id: 'gradient', name: 'Dynamic Gradient', url: '' }, // Uses the CSS gradients
  { id: 'dentist', name: 'Dentist Office', url: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=2068&auto=format&fit=crop' },
  { id: 'office', name: 'Modern Office', url: 'https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=2069&auto=format&fit=crop' },
  { id: 'cute_living', name: 'Cute Living Room', url: 'https://images.unsplash.com/photo-1567016432779-094069958ea5?q=80&w=2070&auto=format&fit=crop' },
];

const AquariumBuilder: React.FC<AquariumBuilderProps> = ({ onBack }) => {
  const [tankItems, setTankItems] = useState<AquariumItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<ItemCategory>(ItemCategory.FISH);
  
  // Scene Settings
  const [lighting, setLighting] = useState<'day' | 'sunset' | 'night'>('day');
  const [filtrationOn, setFiltrationOn] = useState(true);
  const [sandColor, setSandColor] = useState<string>('#e6c288'); // Default Golden
  const [currentBg, setCurrentBg] = useState<string>(''); // Default None (Gradient)
  
  const [showSceneMenu, setShowSceneMenu] = useState(false);
  
  const [aiFeedback, setAiFeedback] = useState<string | null>(null);
  const [loadingFeedback, setLoadingFeedback] = useState(false);

  const tankRef = useRef<HTMLDivElement>(null);

  // --- ITEM MANAGEMENT ---

  const addItem = (def: ItemDefinition, customPos?: {x: number, y: number}) => {
    // Default Z-Index logic for manual addition
    let defaultZ = 10;
    if (def.category === ItemCategory.FISH) defaultZ = 20;
    if (def.category === ItemCategory.PLANT) defaultZ = 5; 
    if (def.category === ItemCategory.DECOR) defaultZ = 15;

    // Adjust Y for floor items if sand is present to avoid floating
    let startY = customPos ? customPos.y : 20 + Math.random() * 60;
    if (!customPos && (def.category === ItemCategory.PLANT || def.category === ItemCategory.DECOR)) {
        startY = 75 + Math.random() * 10; // Bias towards bottom for click-to-add
    }

    const newItem: AquariumItem = {
      id: uuidv4(),
      typeId: def.id,
      category: def.category,
      emoji: def.emoji,
      name: def.name,
      x: customPos ? customPos.x : 20 + Math.random() * 60,
      y: startY,
      z: defaultZ,
      scale: def.defaultScale,
      rotation: 0,
      isFlipped: false,
      movement: def.movement,
      animDuration: 3 + Math.random() * 4,
      animDelay: Math.random() * 2,
    };
    setTankItems(prev => [...prev, newItem]);
    setSelectedItem(newItem.id);
  };

  const updateItem = (id: string, updates: Partial<AquariumItem>) => {
    setTankItems(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
  };

  const removeItem = (id: string) => {
    setTankItems(prev => prev.filter(item => item.id !== id));
    setSelectedItem(null);
  };

  const handleClear = () => {
    setTankItems([]);
    setSelectedItem(null);
  };

  // --- NATURAL AQUASCAPE RANDOMIZER ---
  const handleRandomize = () => {
    const newItems: AquariumItem[] = [];
    
    // Pick random lighting
    const lights: ('day'|'sunset'|'night')[] = ['day', 'sunset', 'night'];
    setLighting(lights[Math.floor(Math.random() * lights.length)]);

    // Reset background to gradient sometimes, or keep current
    if (Math.random() > 0.7) setCurrentBg(''); 

    const getRandom = (cat: ItemCategory) => {
      const filtered = ITEM_DEFINITIONS.filter(i => i.category === cat);
      return filtered[Math.floor(Math.random() * filtered.length)];
    };

    // --- BOTTOM ITEMS (Plants, Decorations, Equipment) ---
    // These should be in the "sand part" (bottom ~15-20% of the tank)
    const bottomCategories = [ItemCategory.PLANT, ItemCategory.DECOR, ItemCategory.EQUIPMENT];
    const bottomItemCount = 5 + Math.floor(Math.random() * 4); // 5 to 8 items
    
    // Divide the bottom width into slots to ensure spacing
    const bottomSlotWidth = 80 / bottomItemCount; // Spread across 10% to 90%
    const bottomSlots = Array.from({ length: bottomItemCount }, (_, i) => ({
      xMin: 10 + (i * bottomSlotWidth),
      width: bottomSlotWidth
    })).sort(() => Math.random() - 0.5); // Shuffle order slightly for variety in Z-index/type

    bottomSlots.forEach((slot, i) => {
      const randomCat = bottomCategories[Math.floor(Math.random() * bottomCategories.length)];
      const def = getRandom(randomCat);

      // Position: 
      // X: Within the slot with some padding
      // Y: 75% to 88% (Sitting on/in sand)
      const xPos = slot.xMin + Math.random() * (slot.width * 0.6);
      const yPos = 75 + Math.random() * 13; 

      newItems.push({
        id: uuidv4(),
        typeId: def.id,
        category: def.category,
        emoji: def.emoji,
        name: def.name,
        x: xPos, 
        y: yPos,
        z: 5 + Math.floor(Math.random() * 15), // Background/Midground
        scale: def.defaultScale * (0.9 + Math.random() * 0.4),
        rotation: (def.category === ItemCategory.PLANT) ? (Math.random() - 0.5) * 15 : 0,
        isFlipped: Math.random() > 0.5,
        movement: def.movement,
        animDuration: 3 + Math.random() * 3,
        animDelay: Math.random() * 2,
      });
    });

    // --- MIDDLE ITEMS (Fish & Invertebrates) ---
    // These should be in the "middle" (water column), avoiding the very top and bottom
    const fishCount = 4 + Math.floor(Math.random() * 5); // 4 to 8 fish
    
    // Use a grid system for fish to ensure they are spaced out
    // 3 rows x 3 cols = 9 zones covering the water area (10% to 70% Y)
    const fishZones = [];
    for(let r=0; r<3; r++) {
      for(let c=0; c<3; c++) {
        fishZones.push({ 
          xMin: 10 + (c * 28), // 10-38, 38-66, 66-94
          yMin: 10 + (r * 20)  // 10-30, 30-50, 50-70
        });
      }
    }
    fishZones.sort(() => Math.random() - 0.5); // Shuffle zones

    for (let i = 0; i < Math.min(fishCount, fishZones.length); i++) {
      const def = getRandom(ItemCategory.FISH);
      const zone = fishZones[i];
      
      newItems.push({
        id: uuidv4(),
        typeId: def.id,
        category: def.category,
        emoji: def.emoji,
        name: def.name,
        x: zone.xMin + Math.random() * 15,
        y: zone.yMin + Math.random() * 10,
        z: 20 + Math.floor(Math.random() * 20), // Foreground
        scale: def.defaultScale * (0.8 + Math.random() * 0.4),
        rotation: 0,
        isFlipped: Math.random() > 0.5,
        movement: def.movement,
        animDuration: 2 + Math.random() * 4,
        animDelay: Math.random(),
      });
    }

    setTankItems(newItems);
    setSelectedItem(null);
  };

  const getAiReview = async () => {
    setLoadingFeedback(true);
    setAiFeedback(null);
    const feedback = await analyzeAquarium(tankItems);
    setAiFeedback(feedback);
    setLoadingFeedback(false);
  };

  // --- ANIMATION VARIANTS ---
  const getAnimation = (item: AquariumItem) => {
    switch(item.movement) {
      case 'swim':
        return {
          x: item.isFlipped ? [-10, 10, -10] : [10, -10, 10],
          y: [-5, 5, -5],
          rotate: [0, 2, -2, 0],
          transition: { duration: item.animDuration, repeat: Infinity, ease: "easeInOut" as const, delay: item.animDelay }
        };
      case 'sway':
        return {
          rotate: [-5, 5, -5],
          skewX: [-3, 3, -3],
          transition: { duration: item.animDuration + 2, repeat: Infinity, ease: "easeInOut" as const, delay: item.animDelay }
        };
      case 'float':
        return {
          y: [-10, 10, -10],
          rotate: [-3, 3, -3],
          transition: { duration: item.animDuration, repeat: Infinity, ease: "easeInOut" as const, delay: item.animDelay }
        };
      case 'crawl':
        return {
          x: [-5, 5, -5],
          transition: { duration: item.animDuration * 2, repeat: Infinity, ease: "easeInOut" as const, delay: item.animDelay }
        };
      default:
        return {};
    }
  };

  const bgStyles = {
    day: 'bg-gradient-to-b from-cyan-300 to-blue-500',
    sunset: 'bg-gradient-to-b from-orange-300 via-pink-400 to-purple-800',
    night: 'bg-gradient-to-b from-slate-900 via-blue-900 to-black',
  };

  const categoryIcons = {
    [ItemCategory.FISH]: Fish,
    [ItemCategory.PLANT]: Leaf,
    [ItemCategory.DECOR]: Anchor,
    [ItemCategory.EQUIPMENT]: Box,
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-50 font-sans">
      {/* Top Bar */}
      <div className="h-16 bg-white shadow-sm flex items-center justify-between px-4 z-20 border-b border-gray-200">
        
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 bg-blue-50 text-blue-600 rounded-full hover:bg-blue-100 transition"
            title="Back"
          >
            <ArrowLeft size={24} />
          </button>
          <h2 className="font-bubble text-2xl text-blue-600 hidden md:block">Anna's Aquarium</h2>
        </div>
        
        {/* Controls */}
        <div className="flex items-center gap-2 md:gap-4 overflow-x-auto no-scrollbar py-2">
           
           {/* Scene Menu Toggle */}
           <button 
              onClick={() => setShowSceneMenu(true)}
              className="p-2 rounded-lg transition flex items-center gap-2 border bg-white border-gray-200 text-gray-700 hover:bg-gray-50 shrink-0"
            >
              <Palette size={20} />
              <span className="text-sm font-semibold hidden lg:inline">Scene</span>
            </button>

          <div className="w-px h-8 bg-gray-300 mx-2 shrink-0"></div>

          <button 
            onClick={() => setFiltrationOn(!filtrationOn)}
            className={`p-2 rounded-lg transition flex items-center gap-2 shrink-0 ${filtrationOn ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'}`}
            title="Toggle Filtration"
          >
            <Wind size={20} className={filtrationOn ? 'animate-pulse' : ''} />
            <span className="text-sm font-semibold hidden lg:inline">Bubbles</span>
          </button>

          <button 
            onClick={handleRandomize}
            className="p-2 rounded-lg bg-pink-100 text-pink-600 hover:bg-pink-200 transition flex items-center gap-2 shrink-0 ml-2"
            title="Surprise Me!"
          >
            <Dices size={20} />
            <span className="text-sm font-semibold hidden lg:inline">Randomize</span>
          </button>

          <button 
            onClick={handleClear}
            className="p-2 rounded-lg bg-red-100 text-red-600 hover:bg-red-200 transition flex items-center gap-2 shrink-0 ml-2"
            title="Clear All"
          >
            <Eraser size={20} />
            <span className="text-sm font-semibold hidden lg:inline">Clear</span>
          </button>

          <div className="w-px h-8 bg-gray-300 mx-2 shrink-0"></div>
          
          <button 
            onClick={getAiReview}
            disabled={loadingFeedback}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-md flex items-center gap-2 transition transform active:scale-95 shrink-0"
          >
            {loadingFeedback ? (
              <span className="animate-spin">⌛</span>
            ) : (
              <Info size={18} />
            )}
            <span className="hidden sm:inline">Expert</span>
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-20 md:w-72 bg-white border-r border-gray-200 flex flex-col z-10 shadow-lg relative">
          
          {/* Categories */}
          <div className="flex flex-col">
             <div className="flex flex-col mt-2 px-2">
               {Object.values(ItemCategory).map(cat => {
                 const Icon = categoryIcons[cat] || Box;
                 return (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`flex items-center gap-3 px-3 py-4 md:py-3 mb-1 rounded-xl text-left transition-all
                      ${activeCategory === cat ? 'bg-blue-50 text-blue-600 shadow-sm' : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700'}
                    `}
                  >
                    <Icon size={24} className="shrink-0" />
                    <span className="font-semibold text-sm hidden md:inline">{cat}</span>
                  </button>
                 );
               })}
             </div>
          </div>
          
          {/* Scrollable Item Grid */}
          <div className="flex-1 overflow-y-auto p-3 bg-gray-50/50">
            <motion.div 
              key={activeCategory}
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-20"
            >
              {ITEM_DEFINITIONS.filter(i => i.category === activeCategory).map(item => (
                <button
                  key={item.id}
                  onClick={() => addItem(item)}
                  className="bg-white hover:bg-blue-50 border border-gray-200 hover:border-blue-300 rounded-xl p-3 flex flex-col items-center gap-2 transition-all transform hover:scale-105 active:scale-95 group shadow-sm"
                >
                  <span className="text-4xl filter drop-shadow-sm group-hover:drop-shadow-md transition-all">{item.emoji}</span>
                  <span className="text-xs font-semibold text-gray-600 text-center leading-tight line-clamp-1">{item.name}</span>
                </button>
              ))}
            </motion.div>
          </div>
        </div>

        {/* Main Tank Area */}
        <div className="flex-1 relative flex items-center justify-center bg-gray-200 p-2 md:p-6 overflow-hidden">
          
          <div 
            ref={tankRef}
            className={`w-full h-full max-w-6xl aspect-video rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] border-4 md:border-8 border-gray-800/50 relative overflow-hidden transition-colors duration-1000 ${bgStyles[lighting]}`}
          >
            {/* Real Life Background Image (Animated Pan) */}
            {currentBg && (
                <div className="absolute inset-0 z-[1] overflow-hidden rounded-2xl bg-white">
                    <motion.div 
                        className="w-full h-full bg-cover bg-center"
                        style={{ backgroundImage: `url(${currentBg})` }}
                        animate={{ scale: [1, 1.1], x: [0, -20] }}
                        transition={{ duration: 20, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
                    />
                    {/* Overlay to blend with lighting */}
                    <div className={`absolute inset-0 mix-blend-multiply opacity-50 ${lighting === 'night' ? 'bg-blue-900' : lighting === 'sunset' ? 'bg-orange-300' : 'bg-transparent'}`}></div>
                </div>
            )}

            {/* Default Water/Light Effects (Only if no BG or transparent) */}
            {!currentBg && (
              <>
                 <div className="absolute top-0 left-0 w-full h-1/3 bg-gradient-to-b from-white/20 to-transparent pointer-events-none z-0"></div>
                 {lighting === 'day' && (
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none"></div>
                 )}
              </>
            )}

            {/* SAND LAYER - Sits at bottom */}
            {sandColor !== 'transparent' && (
                <div 
                    className="absolute bottom-0 left-0 w-full h-[15%] pointer-events-none z-10 border-t-4 border-black/5"
                    style={{ 
                        backgroundColor: sandColor,
                        // Grain texture
                        backgroundImage: `url("data:image/svg+xml,%3Csvg width='4' height='4' viewBox='0 0 4 4' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 3h1v1H1V3zm2-2h1v1H3V1z' fill='%23000000' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E")`
                    }}
                >
                    {/* Simulated uneven sand surface */}
                    <div className="absolute -top-4 left-0 w-full h-8 bg-current opacity-100" 
                         style={{ 
                            backgroundColor: sandColor, 
                            maskImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 100 20\' xmlns=\'http://www.w3.org/2000/svg\' preserveAspectRatio=\'none\'%3E%3Cpath d=\'M0 20 L0 10 Q25 0 50 10 Q75 20 100 10 L100 20 Z\' fill=\'black\'/%3E%3C/svg%3E")',
                            maskSize: '100% 100%',
                            backgroundImage: `url("data:image/svg+xml,%3Csvg width='4' height='4' viewBox='0 0 4 4' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 3h1v1H1V3zm2-2h1v1H3V1z' fill='%23000000' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E")`
                         }}
                    ></div>
                </div>
            )}

            {/* Bubbles Layer */}
            {filtrationOn && (
               <div className="absolute bottom-0 left-10 w-20 h-full pointer-events-none opacity-50 z-10">
                  {[...Array(8)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute bottom-0 bg-white rounded-full opacity-60"
                      style={{ 
                        width: Math.random() * 10 + 5, 
                        height: Math.random() * 10 + 5, 
                        left: Math.random() * 40 
                      }}
                      animate={{ y: -800, opacity: 0 }}
                      transition={{ 
                        duration: Math.random() * 5 + 5, 
                        repeat: Infinity, 
                        ease: "linear",
                        delay: Math.random() * 5 
                      }}
                    />
                  ))}
               </div>
            )}

            {/* Tank Items */}
            {tankItems.map((item) => (
              <motion.div
                key={item.id}
                drag
                dragConstraints={tankRef}
                dragMomentum={false}
                onDragStart={() => setSelectedItem(item.id)}
                onTap={() => setSelectedItem(item.id)}
                className={`absolute cursor-grab active:cursor-grabbing select-none flex items-center justify-center`}
                style={{
                  fontSize: `${3 * item.scale}rem`,
                  filter: item.id === selectedItem ? 'drop-shadow(0 0 10px rgba(255,255,255,0.5))' : 'drop-shadow(0 4px 6px rgba(0,0,0,0.2))',
                  left: `${item.x}%`, 
                  top: `${item.y}%`,
                  zIndex: selectedItem === item.id ? 100 : item.z, 
                }}
                initial={{ scale: 0, opacity: 0 }}
                // Initial placement
                animate={{ 
                  scale: 1, 
                  opacity: 1, 
                }}
              >
                {/* Selection Ring */}
                {selectedItem === item.id && (
                  <div className="absolute w-[120%] h-[120%] border-2 border-dashed border-white/50 rounded-full animate-spin-slow pointer-events-none"></div>
                )}
                
                {/* INNER ANIMATION CONTAINER */}
                <motion.div
                  animate={getAnimation(item)}
                  style={{
                    scaleX: item.isFlipped ? -1 : 1,
                    rotate: item.rotation
                  }}
                  className="pointer-events-none"
                >
                   {item.emoji}
                </motion.div>
              </motion.div>
            ))}

            {/* Glass Reflection Overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-black/10 pointer-events-none rounded-2xl z-40 shadow-inner"></div>
          </div>

          {/* Context Menu for Selected Item */}
          <AnimatePresence>
            {selectedItem && (
              <motion.div 
                initial={{ y: 100, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 100, opacity: 0 }}
                className="absolute bottom-8 bg-white/90 backdrop-blur shadow-xl rounded-2xl p-2 flex gap-4 items-center z-50 border border-gray-200"
              >
                <div className="flex gap-1 border-r pr-4 border-gray-300">
                  <button 
                    onClick={() => {
                       const item = tankItems.find(i => i.id === selectedItem);
                       if (item) updateItem(selectedItem, { scale: Math.min(item.scale + 0.1, 5) });
                    }} 
                    className="p-2 hover:bg-blue-100 rounded-lg text-gray-700" title="Grow"
                  >
                    <ZoomIn size={20} />
                  </button>
                  <button 
                    onClick={() => {
                       const item = tankItems.find(i => i.id === selectedItem);
                       if (item) updateItem(selectedItem, { scale: Math.max(item.scale - 0.1, 0.5) });
                    }} 
                    className="p-2 hover:bg-blue-100 rounded-lg text-gray-700" title="Shrink"
                  >
                    <ZoomOut size={20} />
                  </button>
                </div>
                
                <div className="flex gap-1 border-r pr-4 border-gray-300">
                   <button 
                    onClick={() => {
                       const item = tankItems.find(i => i.id === selectedItem);
                       if (item) updateItem(selectedItem, { rotation: item.rotation + 45 });
                    }} 
                    className="p-2 hover:bg-blue-100 rounded-lg text-gray-700" title="Rotate"
                  >
                    <RotateCw size={20} />
                  </button>
                   <button 
                    onClick={() => {
                       const item = tankItems.find(i => i.id === selectedItem);
                       if (item) updateItem(selectedItem, { isFlipped: !item.isFlipped });
                    }} 
                    className="p-2 hover:bg-blue-100 rounded-lg text-gray-700 font-bold" title="Flip"
                  >
                    ⇄
                  </button>
                   <button 
                    onClick={() => {
                       const item = tankItems.find(i => i.id === selectedItem);
                       if (item) updateItem(selectedItem, { z: item.z === 100 ? 10 : 100 });
                    }} 
                    className="p-2 hover:bg-blue-100 rounded-lg text-gray-700 font-bold" title="Bring to Front/Back"
                  >
                    ⇵
                  </button>
                </div>

                <button 
                  onClick={() => removeItem(selectedItem)} 
                  className="p-2 hover:bg-red-100 rounded-lg text-red-500" title="Remove"
                >
                  <Trash2 size={20} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* AI Feedback Modal */}
          <AnimatePresence>
            {aiFeedback && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="absolute top-20 md:top-10 bg-white rounded-2xl shadow-2xl p-6 max-w-sm md:max-w-md z-50 border-2 border-purple-200"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-purple-100 p-3 rounded-full">
                    <span className="text-2xl">🧞‍♂️</span>
                  </div>
                  <div>
                    <h3 className="font-bubble text-xl text-purple-700 mb-1">The Fish Expert Says:</h3>
                    <p className="text-gray-700 leading-relaxed text-sm md:text-base">{aiFeedback}</p>
                  </div>
                  <button onClick={() => setAiFeedback(null)} className="text-gray-400 hover:text-gray-600">
                    ✕
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* SCENE SETTINGS MODAL - Centered */}
          <AnimatePresence>
            {showSceneMenu && (
              <div 
                className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4"
                onClick={() => setShowSceneMenu(false)}
              >
                <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    className="bg-white rounded-2xl shadow-2xl border border-gray-200 p-6 w-full max-w-md"
                    onClick={(e) => e.stopPropagation()}
                >
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="font-bubble text-2xl text-gray-800">Scene Settings</h3>
                        <button onClick={() => setShowSceneMenu(false)} className="text-gray-400 hover:text-gray-600">
                            <X size={24} />
                        </button>
                    </div>

                    <h4 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Lighting Mode</h4>
                    <div className="flex gap-3 mb-6">
                        <button onClick={() => setLighting('day')} className={`flex-1 p-3 rounded-xl flex flex-col items-center gap-1 transition ${lighting === 'day' ? 'bg-yellow-50 text-yellow-600 ring-2 ring-yellow-400' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}>
                            <Sun size={24} />
                            <span className="text-xs font-semibold">Day</span>
                        </button>
                        <button onClick={() => setLighting('sunset')} className={`flex-1 p-3 rounded-xl flex flex-col items-center gap-1 transition ${lighting === 'sunset' ? 'bg-orange-50 text-orange-600 ring-2 ring-orange-400' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}>
                            <Sunset size={24} />
                            <span className="text-xs font-semibold">Sunset</span>
                        </button>
                        <button onClick={() => setLighting('night')} className={`flex-1 p-3 rounded-xl flex flex-col items-center gap-1 transition ${lighting === 'night' ? 'bg-indigo-50 text-indigo-600 ring-2 ring-indigo-400' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}>
                            <Moon size={24} />
                            <span className="text-xs font-semibold">Night</span>
                        </button>
                    </div>

                    <h4 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Sand Color</h4>
                    <div className="flex gap-3 mb-6 overflow-x-auto pb-2 no-scrollbar">
                        {SAND_COLORS.map(s => (
                        <button 
                            key={s.id} 
                            onClick={() => setSandColor(s.color)}
                            className={`w-10 h-10 rounded-full border-2 shrink-0 transition-transform ${sandColor === s.color ? 'border-blue-500 scale-110 shadow-md' : 'border-gray-200 hover:scale-105'}`}
                            style={{ 
                                backgroundColor: s.color === 'transparent' ? 'white' : s.color, 
                                backgroundImage: s.color === 'transparent' ? 'linear-gradient(45deg, #ccc 25%, transparent 25%, transparent 75%, #ccc 75%, #ccc), linear-gradient(45deg, #ccc 25%, transparent 25%, transparent 75%, #ccc 75%, #ccc)' : 'none', 
                                backgroundSize: '8px 8px' 
                            }}
                            title={s.name}
                        />
                        ))}
                    </div>

                    <h4 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Background Environment</h4>
                    <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
                        {BACKGROUNDS.map(bg => (
                            <button
                                key={bg.id}
                                onClick={() => setCurrentBg(bg.url)}
                                className={`text-sm p-3 rounded-lg border text-left truncate transition ${currentBg === bg.url ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500' : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'}`}
                            >
                                {bg.name}
                            </button>
                        ))}
                    </div>

                </motion.div>
              </div>
            )}
          </AnimatePresence>

        </div>
      </div>
    </div>
  );
};

export default AquariumBuilder;