import { GoogleGenAI } from "@google/genai";
import { AquariumItem } from "../types";

// Helper to get generic item names for privacy/simplicity in prompt
const getItemNames = (items: AquariumItem[]) => items.map(i => i.name).join(', ');

export const analyzeAquarium = async (items: AquariumItem[]) => {
  if (!process.env.API_KEY) {
    console.warn("No API KEY found");
    return "The Fish Expert is sleeping (API Key missing)! But your tank looks amazing!";
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    You are a cheerful, enthusiastic aquarium expert judging a virtual aquarium built for Anna's birthday.
    The user has placed the following items in the tank: ${getItemNames(items)}.
    
    Give a short, fun, 2-sentence review of this aquarium. 
    Compliment the biodiversity or decoration choices. 
    Be whimsical. Mention "Anna" in the review.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Wow! That's a masterpiece fit for Anna!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The Fish Expert is speechless at the beauty of this tank!";
  }
};
